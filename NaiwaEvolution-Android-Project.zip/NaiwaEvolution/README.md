# 奶娃进化（联网版）Android WebView 封装项目

此项目把原网页游戏放进 Android 全屏 WebView。它**不包含网页游戏本体资源**，运行时需要联网访问原站点。

游戏地址：
`https://h5.metaapp.cn/online/h5/BUsvkkbBiAq2pF2Ttx4j/1.0.2/6/index.html`

## 已配置
- 应用显示名称：奶娃进化
- Android WebView 加载线上 H5
- JavaScript、DOM Storage、Cookie 和自动媒体播放支持
- 沉浸式全屏显示
- 游戏视频请求全屏时的基本支持
- 游戏站点内 HTTPS 链接留在应用内，其他 HTTP(S) 链接交给系统浏览器
- 未配置自定义图标（可之后替换）

## 构建 APK

1. 电脑安装 **Android Studio**（建议最新版稳定版）和 Android SDK Platform 35。
2. 解压本项目 ZIP，在 Android Studio 里选择 **Open**，打开 `NaiwaEvolution` 文件夹。
3. 等待 Gradle Sync 完成；首次构建需要联网下载 Android Gradle Plugin 和 Kotlin 插件。
4. 选择 **Build > Build Bundle(s) / APK(s) > Build APK(s)**。
5. 调试 APK 通常输出在 `app/build/outputs/apk/debug/app-debug.apk`。点击 Android Studio 的定位/Locate 可查看实际位置。
6. 将 APK 传到安卓手机安装。若系统提示，允许本次安装来源安装未知应用。

## 命令行构建（已安装 JDK 17、Android SDK 与 Gradle 时）
在项目根目录运行：

```bash
gradle assembleDebug
```

生成位置：`app/build/outputs/apk/debug/app-debug.apk`

## 注意事项
- 本工作区只准备了项目源码，未执行 Android Gradle 构建，也未生成或验证 APK。
- 网址可被在线网页读取工具打开，网页标题返回为“勇者奶蛙传：关于如何从憋笑魔王手中救下公主这件事”；这只能证明页面入口可访问，不能保证所有游戏资源、接口、广告、登录或支付流程在 WebView 中均可正常工作。
- 若游戏使用浏览器专属 API、第三方登录、支付、弹窗或对 WebView 做了限制，可能还需按运行日志继续适配。
- 请确保你有权将该游戏封装并分发。此项目不移除原网页的版权信息、广告或访问控制。
- `applicationId` 当前为 `com.example.naiwaevolution`，正式发布前建议改成自己拥有的唯一包名，并使用自己的签名密钥。

## 无电脑：使用 GitHub Actions 云端编译

项目已附带 `.github/workflows/build-apk.yml`。把整个项目文件夹上传到你自己的 GitHub 仓库后：

1. 打开仓库的 **Actions** 页面。
2. 选择 **Build Naiwa Evolution APK**。
3. 点击 **Run workflow**，再确认运行。
4. 等运行完成，打开本次运行页面底部的 **Artifacts**，下载 `NaiwaEvolution-debug-apk`。
5. 解压下载的 artifact ZIP，得到 `app-debug.apk`，在安卓手机上点开安装。

首次使用需要创建 GitHub 账号和仓库。不要把密码、访问令牌或签名密钥提交到仓库。此工作流生成的是用于测试安装的 debug APK。
